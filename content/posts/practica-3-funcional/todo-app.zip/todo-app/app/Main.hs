module Main where

import System.IO

main :: IO ()
main = do
    putStrLn "=== TODO APP ==="
    menu

menu :: IO ()
menu = do
    putStrLn "1. Agregar tarea"
    putStrLn "2. Ver tareas"
    putStrLn "3. Salir"
    opcion <- getLine
    case opcion of
        "1" -> agregar
        "2" -> ver
        "3" -> putStrLn "Adios!"
        _   -> putStrLn "Opcion invalida" >> menu

agregar :: IO ()
agregar = do
    putStrLn "Escribe la tarea:"
    tarea <- getLine
    appendFile "tareas.txt" (tarea ++ "\n")
    putStrLn "Tarea guardada"
    menu

ver :: IO ()
ver = do
    contenido <- readFile "tareas.txt"
    putStrLn "=== TAREAS ==="
    putStrLn contenido
    menu